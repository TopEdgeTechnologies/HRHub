﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRHUBAPI.Models
{
    public partial class Staff
    {
        [NotMapped] 
        public IEnumerable<Staff>? StaffList { get; set; }
        
        [NotMapped]
        public int TranFlag { get; set; }

        [NotMapped]
        public string Department { get; set; } = string.Empty;

        [NotMapped]
        public string Designation { get; set; } = string.Empty;

        public async Task<List<Staff>> GetStaffByCompanyId(int CompanyId, HrhubContext hrhubContext)
        {
            try
            {
                List<Staff> staff = new List<Staff> ();
                staff = await hrhubContext.Staff.Where(x => x.IsDeleted == false && x.CompanyId == CompanyId).ToListAsync();

                var staffJoin = from ss in hrhubContext.Staff
                                join dd in hrhubContext.Departments on ss.DepartmentId equals dd.DepartmentId
                                join ds in hrhubContext.Designations on ss.DesignationId equals ds.DesignationId
                                select new Staff
                                {
									Department = dd.Title,
                                    Designation = dd.Title,
									StaffID = ss.StaffID,
									DesignationID = ss.DesignationID,
									DepartmentID = ss.DepartmentID,
									RegistrationNo = ss.RegistrationNo,
									NationalIDNumber = ss.NationalIDNumber,
									Name = ss.Name,
									FatherName = ss.FatherName,
									ContactNumber = ss.ContactNumber,
									EmergencyContact1 = ss.EmergencyContact1,
									EmergencyContact2 = ss.EmergencyContact2,
									DOB = ss.DOB,
									Gender = ss.Gender,
									MaterialStatus = ss.MaterialStatus,
									BloodGroup = ss.BloodGroup,
									Email = ss.Email,
									PresentAddress = ss.PresentAddress,
									PermanentAddress = ss.PermanentAddress,
									JoiningDate = ss.JoiningDate,
									ResigningDate = ss.ResigningDate,
									TerminationDate = ss.TerminationDate,
									SalaryPerMonth = ss.SalaryPerMonth,
									AccountTitle = ss.AccountTitle,
									BankAccountNumber = ss.BankAccountNumber,
									BankName = ss.BankName,
									BankLocation = ss.BankLocation,
									TaxPayerNumber = ss.TaxPayerNumber,
									Status = ss.Status,
									JobDescription = ss.JobDescription,
									IsDeleted = ss.IsDeleted,
									CreatedBy = ss.CreatedBy,
									UpdatedBy = ss.UpdatedBy,
									CreatedOn = ss.CreatedOn,
									UpdatedOn = ss.UpdatedOn,
									CompanyID = ss.CompanyID
								};

				return staff;   
            } catch { throw; }
        }

        public async Task<Staff> GetStaffById(int Id, HrhubContext hrhubContext)
        {
            try
            {
                var dbResult = await hrhubContext.Staff.FirstOrDefaultAsync(x => x.IsDeleted == false && x.StaffId == Id);
                if(dbResult != null)
                {
                    return dbResult;
                }
                else
                {
                    return null;
                }
            } catch { throw; }
        }

        public async Task<Staff> PostStaff(Staff staff, HrhubContext hrhubContext)
        {
            try
            {
                var dbResult = await hrhubContext.Staff.FirstOrDefaultAsync(x => x.IsDeleted == false && x.StaffId == staff.StaffId);
                if(dbResult != null && staff.StaffId > 0)
                {
                    dbResult.DesignationId = staff.DesignationId;
                    dbResult.DepartmentId = staff.DepartmentId;
                    dbResult.RegistrationNo = staff.RegistrationNo;
                    dbResult.NationalIdnumber = staff.NationalIdnumber; 
                    dbResult.Name = staff.Name;
                    dbResult.FatherName = staff.FatherName; 
                    dbResult.Gender = staff.Gender; 
                    dbResult.ContactNumber = staff.ContactNumber;   
                    dbResult.EmergencyContact1 = staff.EmergencyContact1;
                    dbResult.EmergencyContact2 = staff.EmergencyContact2;
                    dbResult.Dob = staff.Dob;
                    dbResult.Gender = staff.Gender;
                    dbResult.MaterialStatus = staff.MaterialStatus;
                    dbResult.BloodGroup = staff.BloodGroup;
                    dbResult.Email = staff.Email;
                    dbResult.PresentAddress = staff.PresentAddress; 
                    dbResult.PermanentAddress = staff.PermanentAddress;
                    dbResult.JoiningDate = staff.JoiningDate;
                    dbResult.ResigningDate = staff.ResigningDate;   
                    dbResult.TerminationDate = staff.TerminationDate;   
                    dbResult.SalaryPerMonth = staff.SalaryPerMonth;
                    dbResult.AccountTitle = staff.AccountTitle;
                    dbResult.BankAccountNumber  = staff.BankAccountNumber;  
                    dbResult.BankName = staff.BankName;
                    dbResult.BankLocation = staff.BankLocation;
                    dbResult.TaxPayerNumber = staff.TaxPayerNumber;
                    dbResult.Status = staff.Status;
                    dbResult.JobDescription = staff.JobDescription;
                    dbResult.UpdatedBy = staff.UpdatedBy;
                    dbResult.UpdatedOn = DateTime.Now;

                    await hrhubContext.SaveChangesAsync();
                    dbResult.TranFlag = 2;
                    return dbResult;
                }
                else
                {
                    staff.CreatedOn = DateTime.Now;
                    staff.IsDeleted = false;

                    hrhubContext.Staff.Add(staff);
                    await hrhubContext.SaveChangesAsync();
                    return staff;
                }
            }catch { throw; }
        }

        public async Task<bool> StaffDelete(int id, HrhubContext hrhubContext)
        {
            try
            {
                bool recordDeleted = false;
                var dbResult = await hrhubContext.Staff.FirstOrDefaultAsync(x => x.IsDeleted == false && x.StaffId == id);
                if(dbResult != null)
                {
                    dbResult.IsDeleted = true;
                    dbResult.UpdatedOn = DateTime.Now;
                    recordDeleted = true;
                }
                await hrhubContext.SaveChangesAsync();
                return recordDeleted;
            } catch { throw; }
        }
        
        public async Task<bool> StaffAlreadyExists(int CompanyId, int id, string title, HrhubContext hrhubContext)
        {
            try
            {
                if(id > 0) 
                {
                    var dbResult = await hrhubContext.Staff.FirstOrDefaultAsync(x => x.IsDeleted == false && x.CompanyId == CompanyId && x.Name == title && x.StaffId != id);
                    if(dbResult != null)
                    {
                        return true;
                    }
                }
                else
                {
                    var dbReult = await hrhubContext.Staff.FirstOrDefaultAsync(x => x.IsDeleted == false && x.CompanyId == CompanyId && x.Name == title);
                    if( dbReult != null )
                    {
                        return true;
                    }
                }
                return false;
            }catch { throw; }
        }


	}
}
